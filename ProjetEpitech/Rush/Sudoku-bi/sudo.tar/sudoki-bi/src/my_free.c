/*
** my_free.c for  in /home/bidard_v/rendu/sudoki-bi/src
** 
** Made by bidard_v
** Login   <bidard_v@epitech.net>
** 
** Started on  Sat Mar  1 14:27:22 2014 bidard_v
** Last update Sat Mar  1 16:33:36 2014 bidard_v
*/

#include <stdlib.h>
#include "sudoku.h"

void	my_free(char **sudo, t_sudo *sud)
{
  int	i;

  i = 0;
  while (sudo[i])
    free(sudo[i++]);
  free(sudo);
  free(sud);
}
