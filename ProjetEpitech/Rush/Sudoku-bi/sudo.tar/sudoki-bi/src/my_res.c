/*
** my_res.c for  in /home/bidard_v/rendu/sudoki-bi/src
** 
** Made by bidard_v
** Login   <bidard_v@epitech.net>
** 
** Started on  Sat Mar  1 16:43:35 2014 bidard_v
** Last update Sat Mar  1 17:44:12 2014 bidard_v
*/

#include "sudoku.h"
#include "my.h"

char	**my_res(char **tab, t_sudo *sudo)
{
  sudo->x = 2;
  sudo->y = 1;
  if (sudo->y != 9)
    {
      my_res();
      if (sudo->x == 18)
	{
	  sudo->x = 0;
	  sudo->y++;
	}
    }
  //my_affichage(tab);
  return (tab);
}
