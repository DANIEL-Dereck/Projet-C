/*
** my_init.c for  in /home/bidard_v/rendu/sudoki-bi/src
** 
** Made by bidard_v
** Login   <bidard_v@epitech.net>
** 
** Started on  Sat Mar  1 15:27:23 2014 bidard_v
** Last update Sat Mar  1 16:38:35 2014 bidard_v
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "sudoku.h"

t_sudo	*my_init()
{
  t_sudo	*sudo;

  sudo = malloc(sizeof(*sudo));
  if (sudo == NULL)
    return (NULL);
  return (sudo);
}
