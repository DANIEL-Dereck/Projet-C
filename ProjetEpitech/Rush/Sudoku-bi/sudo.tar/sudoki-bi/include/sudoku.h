/*
** sudoku.h for rush in /home/daniel_d/rendu/Rush-Sudoku-bi/Lib/include
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Sat Mar  1 08:59:51 2014 daniel_d
** Last update Sat Mar  1 17:20:45 2014 bidard_v
*/

#ifndef SUDOKU_H_
#define SUDOKU_H_

typedef struct s_sudo
{
  int	x;
  int	y;
  char	value;
  char	carry;
  int	bool;
} t_sudo;

int	sudokumain(char**);
t_sudo	*my_init();
void	my_free(char**, t_sudo*);
char	**my_res(char**, t_sudo*);
void	my_affichage(char**);

#endif
