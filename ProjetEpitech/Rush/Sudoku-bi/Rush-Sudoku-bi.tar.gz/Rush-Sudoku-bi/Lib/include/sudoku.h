/*
** sudoku.h for rush in /home/daniel_d/rendu/Rush-Sudoku-bi/Lib/include
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Sat Mar  1 08:59:51 2014 daniel_d
** Last update Sat Mar  1 13:48:19 2014 daniel_d
*/

#ifndef SUDOKU_H_
# define SUDOKU_H_

int	sudokumain(char ** av);
char	**epur_sudo(char **sudo);
void	my_free(char **sudo);

#endif
