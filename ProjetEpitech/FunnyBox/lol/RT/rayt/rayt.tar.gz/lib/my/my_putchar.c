/*
** my_putchar.c for my_putchar in /home/julien_t
** 
** Made by julien_t
** Login   <julien_t@epitech.net>
** 
** Started on  Fri Oct 18 19:57:49 2013 julien_t
** Last update Fri Oct 18 19:58:25 2013 julien_t
*/

void my_putchar(char c)
{
  write(1, &c, 1);
}
