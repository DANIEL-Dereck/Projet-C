/*
** my_square_root.c for my_square_root in /home/julien_t
** 
** Made by julien_t
** Login   <julien_t@epitech.net>
** 
** Started on  Sat Oct 19 13:04:41 2013 julien_t
** Last update Sun Dec  8 19:44:41 2013 julien_t
*/

int     my_square_root(int b)
{
  return (0);
}
