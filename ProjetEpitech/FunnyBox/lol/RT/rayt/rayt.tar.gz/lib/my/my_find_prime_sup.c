/*
** my_find_prime_sup.c for my_find_prime_sup in /home/julien_t
** 
** Made by julien_t
** Login   <julien_t@epitech.net>
** 
** Started on  Sat Oct 19 13:10:07 2013 julien_t
** Last update Sat Oct 19 13:11:05 2013 julien_t
*/

int	my_find_prime_sup(int b)
{
  return (0);
}
