/*
** my_is_prime.c for my_is_prime in /home/julien_t
** 
** Made by julien_t
** Login   <julien_t@epitech.net>
** 
** Started on  Sat Oct 19 13:06:07 2013 julien_t
** Last update Sat Oct 19 13:07:32 2013 julien_t
*/

int	my_is_prime(int nombre)
{
  return (0);
}
