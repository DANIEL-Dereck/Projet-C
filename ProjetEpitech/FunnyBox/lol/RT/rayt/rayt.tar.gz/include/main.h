/*
** main.h for main.h in /home/julien_t/Desktop/rayt
** 
** Made by julien_t
** Login   <julien_t@epitech.net>
** 
** Started on  Fri May 16 11:16:00 2014 julien_t
** Last update Mon May 26 11:25:58 2014 julien_t
*/

#ifndef MAIN_H_
# define MAIN_

void    parseur(char *filename);
void    display(char *str, char *filename);
void    display2(char *str, int *i);
void    display3(char *str, int *i);
int     main(int ac, char **av);

#endif
