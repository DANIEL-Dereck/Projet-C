/*
** oeil.h for tp_raycaster in /home/jouana_j/rendu/tp_raytracer/source
** 
** Made by jouana_j
** Login   <jouana_j@epitech.net>
** 
** Started on  Thu Feb  6 15:42:01 2014 jouana_j
** Last update Tue May 13 14:14:31 2014 jouana_j
*/

#ifndef COORD_H_
# define COORD_H_

typedef struct s_coord
{
  float x;
  float y;
  float z;
} t_coord;

#endif
