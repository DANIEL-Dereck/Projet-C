/*
** my_minishell.h for minishell in /home/daniel_d/rendu/minishell_test/include
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Wed Apr 30 11:28:34 2014 daniel_d
** Last update Wed Apr 30 16:18:16 2014 daniel_d
*/

#ifndef MY_MINISHELL_H_
# define MY_MINISHELL_H_

int     my_prompt(char **envp);
int     run_cmd(char **envp, char *buffer);
char    *my_concat_str(char *usrbin, char *cmd);
int     my_cd(char *buffer, char **env);
int     my_clear_prompt(char **envp);
int     my_exit(char *buffer);
char	*my_epurstr(char *str);
void    get_sigall();
int     signal_set();

#endif
