/*
** epur_str.c for my_epur_str in /home/boucha_q/rendu/PSU_2013_minishell1
** 
** Made by bouchard alexandre
** Login   <boucha_q@epitech.net>
** 
** Started on  Wed Feb 26 17:13:22 2014 bouchard alexandre
** Last update Wed Apr 30 16:26:58 2014 daniel_d
*/

#include <stdlib.h>

char	*my_epurstr(char *str)
{
  int	i;
  int	j;

  i = -1;
  j = 0;
  if (!str)
    return (0);
  while (str[++i] != '\0')
    {
      if (str[i] != ' ' && str[i] != '\t')
	{
	  str[j] = str[i];
	  j++;
	  if (str[i + 1] == ' ' || str[i + 1] == '\t')
	    {
	      str[j] = ' ';
	      j++;
	    }
	}
    }
  str[j] = '\0';
  if (str[j - 1] == ' ')
    str[j - 1] = '\0';
  return (str);
}
