/*
** my_prompt.c for minishell in /home/daniel_d/rendu/PSU_2013_minishell1
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Wed Dec 18 16:12:13 2013 daniel_d
** Last update Wed Apr 30 16:21:10 2014 daniel_d
*/

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <unistd.h>
#include "my.h"
#include "my_minishell.h"

char    *my_concat_str(char *usrbin, char *cmd)
{
  int i;
  int k;

  i = 9;
  k = 0;
  if (cmd == NULL)
    return (0);
  while (cmd[k] != '\0' && cmd[k] != '\n' && cmd[k] != ' ')
    usrbin[i++] = cmd[k++];
  return (usrbin);
}

int     run_cmd(char **envp, char *buffer)
{
  pid_t pid;
  int   status;
  char	**cmd;
  char	*usrbin;

  usrbin = my_strdup("/usr/bin/");
  if ((pid = fork()) == 0)
    {
      cmd = my_str_to_wordtab(buffer);
      usrbin = my_concat_str(usrbin, cmd[0]);
      if (execve(usrbin, cmd, envp) == -1)
	my_printf("ERROR : command not found\n");
      exit(1);
    }
  else
    wait(&status);
  return (0);
}

int	my_clear_prompt(char **envp)
{
  int   status;
 pid_t pid;
  char	**cmd;

  cmd = NULL;
  if ((pid = fork()) == 0)
    {
      execve("/usr/bin/clear" , cmd, envp);
      exit(1);
    }
  wait(&status);
  return (0);
}

int	my_prompt(char **envp)
{
  char	*str;
  char	buffer[4096];
  int	r;

  r = 0;
  my_clear_prompt(envp);
  while (42)
    {
      my_printf("daniel_d  -> minishell1 $>");
      signal_set();
      if ((r = read(0, buffer, 4095)) > 0)
	{
	  str = my_strdup(buffer);
	  str = my_epurstr(str);
	  if (my_nmatch("exit", buffer, 4) == 0)
	    return (my_exit(buffer));
	  else if (my_nmatch("cd", buffer, 2) == 0 ||
		   my_nmatch("..", buffer, 2) == 0)
	    my_cd(buffer, envp);
	  else
	    run_cmd(envp, buffer);
	}
      else
	return (0);
    }
  return (0);
}
