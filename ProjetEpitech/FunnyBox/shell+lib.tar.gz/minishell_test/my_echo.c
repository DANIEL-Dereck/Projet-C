/*
** my_echo.c for my_echo in /home/daniel_d/rendu
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Wed Apr 23 09:08:51 2014 daniel_d
** Last update Fri May  2 11:16:30 2014 daniel_d
*/

#include "my.h"

/*
  optn = options
  e = 1
  E = 2
  n = 5
 */

int	check_optn(int optn, int opt)
{
  if (optn != 1 && optn != 3 && optn != 6 && opt == 1)
    {
      if (optn == 2 || optn == 5 || optn == 8)
	optn = optn - 2;
      optn = optn + 1;
    }
  else if (optn != 2 && optn != 3 && optn != 7 && opt == 2)
    {
      if (optn == 1 || optn == 6 || optn == 8)
	optn = optn - 1;
      optn = optn + 2;
    }
  else if (optn != 5 && optn != 6 && optn != 7 && optn != 8 && opt == 5)
    optn = optn + 5;
  i++;
  return (optn);
}

int	my_check(char c)
{
  int	otp;

  opt = 0;
  if (buffer[i] == 'e')
    opt = opt + 1;
  else if (buffer[i] == 'E')
    opt = opt + 2;
  else if (buffer[i] == 'n')
    opt = opt + 5;
  return (opt);
}

int	parsing_echo(char *buffer)
{
  int	opt;
  int	optn;
  int	i;

  optn = 0;
  i = 0;
  while (buffer[i] != '\0')
    {
      if (buffer[i] == '-')
	{
	  while (buffer[i] != ' ')
	    {
	      if ((opt = my_check(buffer[i], optn)) == -1)
		return (-1);
	      optn = check_optn(optn, opt);
	      i++;
	    }
	}
      i++;
    }
  return (optn);
}

int	check_start(char *buffer)
{
  int	i;

  i = 4;
  while (buffer[i] != '\0')
    {
      if (buffer[i] == '-')
	i++;
      else if ((buffer[i] != '-' && buffer[i] != ' ' && buffer[i] != '\t')
	       || buffer[i] == '"')
	return (i);
      i++;
    }
  return (i);
}

int	my_optn_e_min(char *buffer, int boule)
{

}

int	my_optn_e_maj(char *buffer, int boule)
{

}

}

int	my_echo(char *buffer)
{
  int	boule;
  int	optn;

  boule = 0;
  optn = 0;
  if ((optn = parsing_echo(buffer)) == -1)
    return (-1);
  if (optn == 1 || optn == 3 || optn == 6 || optn == 8)
    my_optn_e_min(buffer, boule);
  else
    my_optn_e_maj(buffer, boule);
  if (optn != 5 && optn != 6 && optn != 7 && optn != 8)
    my_putchar('\n');
}
