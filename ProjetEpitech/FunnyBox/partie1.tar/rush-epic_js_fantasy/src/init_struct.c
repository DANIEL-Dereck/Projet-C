/*
** init_strcut.c for init in /home/daniel_d/rendu/rush-epic_js_fantasy/src
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Sat May 10 14:36:51 2014 daniel_d
** Last update Sat May 10 15:01:17 2014 daniel_d
*/

#include <stdlib.h>
#include <stdio.h>
#include "my.h"
#include "epic_editor.h"

t_header	*init_header(t_header *h)
{
  h->name = my_strdup("name");
  h->room_to_win = my_strdup("room_to_win");
  h->room_to_start = my_strdup("room_to_start");
  return (h);
}

t_champion	*init_champion(t_champion *c)
{
  c->name = my_strdup("name");
  c->type = my_strdup("type");
  c->hp = my_strdup("hp");
  c->spe = my_strdup("spe");
  c->speed = my_strdup("speed");
  c->deg = my_strdup("deg");
  c->weapon = my_strdup("weapon");
  c->armor = my_strdup("armor");
  return (c);
}

t_monster	*init_monster(t_monster *m)
{
  m->type = my_strdup("type");
  m->hp = my_strdup("hp");
  m->spe = my_strdup("spe");
  m->speed = my_strdup("speed");
  m->deg = my_strdup("deg");
  m->weapon = my_strdup("weapon");
  m->armor = my_strdup("armor");
  return (m);
}

t_room	*init_room(t_room *r)
{
  r->name = my_strdup("name");
  r->adv = my_strdup("adv");
  r->tab_connection = my_strdup("tab_connection");
  r->tab_monster = my_strdup("tab_monster");
  return (r);
}
