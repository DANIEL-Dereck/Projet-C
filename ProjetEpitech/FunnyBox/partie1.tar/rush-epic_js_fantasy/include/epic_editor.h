/*
** epic_editor.h for rush in /home/daniel_d/rendu/rush-epic_js_fantasy/include
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Sat May 10 09:12:01 2014 daniel_d
** Last update Sat May 10 15:06:00 2014 daniel_d
*/

#ifndef EPIC_EDITOR_H_
# define EPIC_EDITOR_H_

/*
** Attributes
*/
#define NAME "1" // string in parameters (0x01)
#define ROOM_TO_WIN "2" // string in parameters (0x02)
#define ROOM_TO_START "3" // string in parameters (0x03)
#define TYPE "4" // string in parameters (0x04)
#define HP "5" // value in parameters (0x05)
#define SPEED "6" // value in parameters (0x06)
#define DEG "7" // value in parameters (0x07)
#define WEAPON "8" // string in parameters (0x08)
#define ARMOR "9" // string in parameters (0x09)
#define ADV "10" // string in parameters (0x10)
#define TAB_CONNECTION "11" // string in parameters (0x11)
#define TAB_MONSTER "12" // string in parameters (0x12)
#define ROOM "13" // string in parameters (0x0F)
#define SPE "14" // value in parameters (0x20)
/*
** Section
*/
#define CHAMPION "15" // no parameters (0x0C)
#define HEADER "16" // no parameters (0x0D)
#define MONSTER "17" // no parameters (0x0E)
/*
** Others
*/
#define SPE_SECTION "18" // no parameters (0x0A)
#define MAGIC_NUMBER "123" // no parameters (0x123)
/*
** char
*/
#define LF "\n"
#define SPACE " "

typedef struct s_header
{
  char	*name;
  char	*room_to_win;
  char	*room_to_start;
} t_header;

typedef struct s_champion
{
  char	*name;
  char	*type;
  char	*hp;
  char	*spe;
  char	*speed;
  char	*deg;
  char	*weapon;
  char	*armor;
} t_champion;

typedef struct s_monster
{
  char	*type;
  char	*hp;
  char	*spe;
  char	*speed;
  char	*deg;
  char	*weapon;
  char	*armor;
} t_monster;

typedef struct s_room
{
  char	*name;
  char	*adv;
  char	*tab_connection;
  char	*tab_monster;
} t_room;

/*
** creat_file
*/
int     remp_file(int fd, char **tab);
int     creat_file(char *name, char **tab);
/*
** remp_file
*/
t_header        *init_header(t_header *h);
t_champion      *init_champion(t_champion *c);
t_monster       *init_monster(t_monster *m);
t_room  *init_room(t_room *r);
int     add_file(int fd, char *option, char *str, int bool);
int	header(int fd, t_header *h);
int	champion(int fd, t_champion *c);
int	monster(int fd, t_monster *m);
int	room(int fd, t_room *r);
int     resum_error(int *verif, int size);

#endif
