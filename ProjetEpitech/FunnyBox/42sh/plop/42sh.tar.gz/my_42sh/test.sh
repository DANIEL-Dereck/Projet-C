alias bonjour='salut'
alias salut='lol'
alias lol='plop'
