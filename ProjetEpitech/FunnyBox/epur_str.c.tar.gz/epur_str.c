/*
** epur_str.c for my_epur_str in /home/boucha_q/rendu/PSU_2013_minishell1
** 
** Made by bouchard alexandre
** Login   <boucha_q@epitech.net>
** 
** Started on  Wed Feb 26 17:13:22 2014 bouchard alexandre
** Last update Sun Mar  9 16:56:26 2014 bouchard alexandre
*/

#include <stdlib.h>
#include "lib/my.h"
#include "proto.h"

char	*my_epur_str(char *str)
{
  int	i;
  int	j;

  i = -1;
  j = 0;
  if (!str)
    return (0);
  while (str[++i] != '\0')
    {
      if (str[i] != ' ' && str[i] != '\t')
	{
	  str[j] = str[i];
	  j++;
	  if (str[i + 1] == ' ' || str[i + 1] == '\t')
	    {
	      str[j] = ' ';
	      j++;
	    }
	}
    }
  str[j] = '\0';
  if (str[j - 1] == ' ')
    str[j - 1] = '\0';
  return (str);
}
