pwd
head -6 coffre-fort
date

