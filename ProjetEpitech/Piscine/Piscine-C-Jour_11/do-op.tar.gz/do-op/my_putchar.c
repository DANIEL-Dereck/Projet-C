/*
** my_putchar.c for my_putchar in /home/daniel_d/rendu/Piscine-C-Jour_11/do-op
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Mon Oct 28 12:20:34 2013 daniel_d
** Last update Mon Oct 28 12:20:57 2013 daniel_d
*/

int	my_putchar(char c)
{
  write(1, &c, 1);
}
