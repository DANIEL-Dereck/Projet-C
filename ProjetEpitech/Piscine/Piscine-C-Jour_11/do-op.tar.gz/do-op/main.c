/*
** main.c for do-op in /home/daniel_d/rendu/Piscine-C-Jour_11/do-op
** 
** Made by daniel_d
** Login   <daniel_d@epitech.net>
** 
** Started on  Mon Oct 28 11:51:52 2013 daniel_d
** Last update Mon Oct 28 12:11:12 2013 daniel_d
*/

int	main(int ac, char **av)
{
  int a;
  char *oper;
  int b;

  a = av[1];
  oper = av[2];
  b = av[3];

  my_put_nbr(my_oper(a, oper, b));
}
